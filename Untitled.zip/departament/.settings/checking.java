package accounting;

public class checking {

	private static final char[] Balance = null;

	String account = "Balance";
	
	int spent = 1400;
	
	double tax = 14.44;
	
	char time = 'h';
	
	public void day () 
	{
		
	
		System.out.println(Balance);
		
	}
	 
	
	
	public void month () {
		
		System.out.println(spent);
		
		
}
	
	
	public void years () 
	
	{
	

		System.out.println(time);
		
		}
	
	
	
	public void payroll () 
	{
		
		System.out.println(time);
		
		
	}
	
	
	
	
	
	
	
	
