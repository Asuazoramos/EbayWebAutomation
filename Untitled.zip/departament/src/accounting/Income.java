package accounting;

public class Income {
	
	String calculate = "Money";
	
	
	int spent = 16800;
	
	
	double  amount = 349.98;
	
	  
	char day = 'D';
			
			
	
	public void copy() 
	{
		
	System.out.println(calculate);
		
	}
	
	
	
	
	
	public void printSpring() 
	{
		
	System.out.println(amount);
	}	
	
	
	
	
	public void PrintSpring() 
	{
		
	System.out.println(day);
	}
	
	
	
	













}
