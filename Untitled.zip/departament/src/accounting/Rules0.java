package accounting;



public class Rules0 {
	
	
	
	
	
	


	String follow = "ControlPanel";
	
	
	int lost = 29877;
	
	
	double amount = 139.99;
	

	char hours =  'T';
	
	
	
	
	
	
	
	
	public void copy ()
	{
		
	
		System.out.println(follow);
		
		
		
		
	}
	
	
		
		public void however() 
		{
		
		System.out.print(lost);
		
		
		}
			
			
			public void moneymaker () 
			{
	
	
	System.out.print(amount);
	}
	
	
	
	public void companies() 
	{
	
	System.out.println(hours);
	
	
	
	
	
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}