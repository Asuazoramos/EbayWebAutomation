package Objects;

import accounting.Checking;

public class Accounts {
	
	
public static void main(String[] args) {
	
	Checking checking = new Checking();
	
	checking.day();
	checking.month();
	checking.payroll();
	checking.years();
	
	
}
	
	
	

}
